#!/bin/bash

echo "===> Lancement des tests Robot Framework"
robot tests/
