
from models import Pilote

def test_pilote_creation():
    p = Pilote(2, "Durand", "XYZ999")
    assert p.id == 2
    assert p.nom == "Durand"
    assert p.licence == "XYZ999"
