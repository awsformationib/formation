
from models import Avion

def test_avion_creation():
    a = Avion(1, "A320", "Court-courrier", 850)
    assert a.id == 1
    assert a.modele == "A320"
    assert a.description == "Court-courrier"
    assert a.vitesse_max == 850
