
import requests

BASE = "http://localhost:5000/api/vols"

def test_post_get_vol():
    v = {
        "numero": "TEST01",
        "destination": "Paris",
        "statut": "prévu",
        "heure_decollage": "2025-06-10T10:00:00",
        "heure_arrivee": "2025-06-10T12:00:00",
        "avion_id": 1,
        "pilote_id": 1
    }
    r1 = requests.post(BASE, json=v)
    assert r1.status_code == 201
    r2 = requests.get(BASE)
    assert any(x["numero"] == "TEST01" for x in r2.json())
    requests.delete(f"{BASE}/TEST01")
