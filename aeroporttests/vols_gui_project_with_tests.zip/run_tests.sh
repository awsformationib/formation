#!/bin/bash
pytest tests/ -v
