
from flask import Flask, jsonify, request, abort
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

avions = [
    {"id": 1, "modele": "A320", "description": "Avion court-courrier", "vitesse_max": 870},
    {"id": 2, "modele": "B777", "description": "Long-courrier", "vitesse_max": 905}
]

pilotes = [
    {"id": 1, "nom": "Dupont", "licence": "ABC123"},
    {"id": 2, "nom": "Durand", "licence": "XYZ789"}
]

vols = [
    {
        "numero": "AF123",
        "destination": "Tokyo",
        "statut": "prévu",
        "heure_decollage": "2025-06-10T10:00:00",
        "heure_arrivee": "2025-06-10T18:30:00",
        "avion_id": 2,
        "pilote_id": 1
    }
]

@app.route("/api/avions", methods=["GET", "POST"])
def get_or_add_avions():
    if request.method == "GET":
        return jsonify(avions)
    data = request.get_json()
    avions.append(data)
    return jsonify({"message": "Avion ajouté"}), 201

@app.route("/api/avions/<int:avion_id>", methods=["PUT", "DELETE"])
def update_or_delete_avion(avion_id):
    global avions
    avion = next((a for a in avions if a["id"] == avion_id), None)
    if not avion:
        abort(404)
    if request.method == "PUT":
        data = request.get_json()
        avion.update(data)
        return jsonify({"message": "Avion modifié"})
    if request.method == "DELETE":
        avions = [a for a in avions if a["id"] != avion_id]
        return jsonify({"message": "Avion supprimé"}), 204

@app.route("/api/pilotes", methods=["GET", "POST"])
def get_or_add_pilotes():
    if request.method == "GET":
        return jsonify(pilotes)
    data = request.get_json()
    pilotes.append(data)
    return jsonify({"message": "Pilote ajouté"}), 201

@app.route("/api/pilotes/<int:pilote_id>", methods=["PUT", "DELETE"])
def update_or_delete_pilote(pilote_id):
    global pilotes
    pilote = next((p for p in pilotes if p["id"] == pilote_id), None)
    if not pilote:
        abort(404)
    if request.method == "PUT":
        data = request.get_json()
        pilote.update(data)
        return jsonify({"message": "Pilote modifié"})
    if request.method == "DELETE":
        pilotes = [p for p in pilotes if p["id"] != pilote_id]
        return jsonify({"message": "Pilote supprimé"}), 204

@app.route("/api/vols", methods=["GET", "POST"])
def get_or_add_vols():
    if request.method == "GET":
        return jsonify(vols)
    data = request.get_json()
    vols.append(data)
    return jsonify({"message": "Vol ajouté"}), 201

@app.route("/api/vols/<numero>", methods=["PUT", "DELETE"])
def update_or_delete_vol(numero):
    global vols
    vol = next((v for v in vols if v["numero"] == numero), None)
    if not vol:
        abort(404)
    if request.method == "PUT":
        data = request.get_json()
        vol.update(data)
        return jsonify({"message": "Vol modifié"})
    if request.method == "DELETE":
        vols = [v for v in vols if v["numero"] != numero]
        return jsonify({"message": "Vol supprimé"}), 204

if __name__ == "__main__":
    app.run(debug=True)
