
class Avion:
    def __init__(self, id, modele, description, vitesse_max):
        self.id = id
        self.modele = modele
        self.description = description
        self.vitesse_max = vitesse_max

class Pilote:
    def __init__(self, id, nom, licence):
        self.id = id
        self.nom = nom
        self.licence = licence

class Vol:
    def __init__(self, numero, destination, statut, heure_decollage, heure_arrivee, avion_id, pilote_id):
        self.numero = numero
        self.destination = destination
        self.statut = statut
        self.heure_decollage = heure_decollage
        self.heure_arrivee = heure_arrivee
        self.avion_id = avion_id
        self.pilote_id = pilote_id
