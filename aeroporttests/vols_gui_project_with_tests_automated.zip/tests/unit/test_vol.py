
from models import Vol

def test_vol_creation():
    v = Vol("AF123", "Tokyo", "prévu", "2025-06-01T10:00", "2025-06-01T18:30", 1, 2)
    assert v.numero == "AF123"
    assert v.destination == "Tokyo"
    assert v.statut == "prévu"
    assert v.avion_id == 1
    assert v.pilote_id == 2
