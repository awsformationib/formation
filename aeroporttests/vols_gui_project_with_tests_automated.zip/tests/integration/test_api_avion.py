
import requests

BASE = "http://localhost:5000/api/avions"

def test_get_avions():
    response = requests.get(BASE)
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_post_avion():
    avion = {"id": 99, "modele": "TestModel", "description": "Test", "vitesse_max": 900}
    response = requests.post(BASE, json=avion)
    assert response.status_code == 201

def test_put_avion():
    update = {"modele": "UpdatedModel"}
    response = requests.put(f"{BASE}/99", json=update)
    assert response.status_code == 200

def test_delete_avion():
    response = requests.delete(f"{BASE}/99")
    assert response.status_code in (204, 200)
