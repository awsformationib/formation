
import requests

BASE = "http://localhost:5000/api/pilotes"

def test_post_get_pilote():
    p = {"id": 88, "nom": "TEST", "licence": "ZZZ"}
    r1 = requests.post(BASE, json=p)
    assert r1.status_code == 201
    r2 = requests.get(BASE)
    assert any(x["id"] == 88 for x in r2.json())
    requests.delete(f"{BASE}/88")
