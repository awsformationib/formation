
import pytest
from PySide6.QtWidgets import QApplication
from main import MainWindow

@pytest.fixture
def app_window(qtbot):
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    return window

def test_ajout_avion_via_dialog(qtbot, app_window):
    btn = app_window.btn_ajouter_avion
    qtbot.mouseClick(btn, QtCore.Qt.LeftButton)

    from dialogs import AvionDialog
    dialog = app_window.findChild(AvionDialog)
    assert dialog is not None

    qtbot.keyClicks(dialog.id_input, "101")
    qtbot.keyClicks(dialog.modele_input, "X-Test")
    qtbot.keyClicks(dialog.desc_input, "Avion test automatique")
    qtbot.keyClicks(dialog.vitesse_input, "888")

    qtbot.mouseClick(dialog.findChild(type(dialog).children(dialog)[-1]), QtCore.Qt.LeftButton)

    # Vérifie que le nouvel avion est bien ajouté
    values = [app_window.table_avions.item(i, 0).text() for i in range(app_window.table_avions.rowCount())]
    assert "101" in values
