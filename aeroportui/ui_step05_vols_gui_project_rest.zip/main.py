
from PySide6.QtWidgets import QApplication, QMainWindow, QTabWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QPushButton, QHBoxLayout, QMessageBox
from dialogs import AvionDialog, PiloteDialog, VolDialog
from models import Avion, Pilote, Vol
import sys, json, os

def charger_json(path, cls):
    with open(path, encoding="utf-8") as f:
        return [cls(**x) for x in json.load(f)]

def remplir_table(table, objets, attributs):
    table.setRowCount(len(objets))
    for row, obj in enumerate(objets):
        for col, attr in enumerate(attributs):
            val = getattr(obj, attr)
            table.setItem(row, col, QTableWidgetItem(str(val)))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gestion des vols")
        self.resize(1000, 600)
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        self.avions = charger_json("data/avions.json", Avion)
        self.pilotes = charger_json("data/pilotes.json", Pilote)
        self.vols = charger_json("data/vols.json", Vol)

        self.setup_tabs()

    def setup_tabs(self):
        self.setup_avions_tab()
        self.setup_pilotes_tab()
        self.setup_vols_tab()

    def setup_avions_tab(self):
        self.table_avions = self.create_table(["id", "modele", "description", "vitesse_max"])
        self.btn_ajouter_avion = QPushButton("Ajouter un avion")
        self.btn_ajouter_avion.clicked.connect(self.ajouter_avion)
        layout = QVBoxLayout()
        layout.addWidget(self.table_avions)
        layout.addWidget(self.btn_ajouter_avion)
        conteneur = QWidget()
        conteneur.setLayout(layout)
        self.tabs.addTab(conteneur, "Avions")
        remplir_table(self.table_avions, self.avions, ["id", "modele", "description", "vitesse_max"])

    def setup_pilotes_tab(self):
        self.table_pilotes = self.create_table(["id", "nom", "licence"])
        self.btn_ajouter_pilote = QPushButton("Ajouter un pilote")
        self.btn_ajouter_pilote.clicked.connect(self.ajouter_pilote)
        layout = QVBoxLayout()
        layout.addWidget(self.table_pilotes)
        layout.addWidget(self.btn_ajouter_pilote)
        conteneur = QWidget()
        conteneur.setLayout(layout)
        self.tabs.addTab(conteneur, "Pilotes")
        remplir_table(self.table_pilotes, self.pilotes, ["id", "nom", "licence"])

    def setup_vols_tab(self):
        self.table_vols = self.create_table(["numero", "destination", "statut", "heure_decollage", "heure_arrivee", "avion_id", "pilote_id"])
        self.btn_ajouter_vol = QPushButton("Ajouter un vol")
        self.btn_ajouter_vol.clicked.connect(self.ajouter_vol)
        layout = QVBoxLayout()
        layout.addWidget(self.table_vols)
        layout.addWidget(self.btn_ajouter_vol)
        conteneur = QWidget()
        conteneur.setLayout(layout)
        self.tabs.addTab(conteneur, "Vols")
        remplir_table(self.table_vols, self.vols, ["numero", "destination", "statut", "heure_decollage", "heure_arrivee", "avion_id", "pilote_id"])

    def create_table(self, headers):
        table = QTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        return table

    def ajouter_avion(self):
        dialog = AvionDialog(on_submit=self.handle_ajout_avion, parent=self)
        dialog.exec()

    def ajouter_pilote(self):
        dialog = PiloteDialog(on_submit=self.handle_ajout_pilote, parent=self)
        dialog.exec()

    def ajouter_vol(self):
        dialog = VolDialog(on_submit=self.handle_ajout_vol, parent=self)
        dialog.exec()

    def handle_ajout_avion(self, avion_data):
        avion = Avion(**avion_data)
        self.avions.append(avion)
        remplir_table(self.table_avions, self.avions, ["id", "modele", "description", "vitesse_max"])

    def handle_ajout_pilote(self, pilote_data):
        pilote = Pilote(**pilote_data)
        self.pilotes.append(pilote)
        remplir_table(self.table_pilotes, self.pilotes, ["id", "nom", "licence"])

    def handle_ajout_vol(self, vol_data):
        vol = Vol(**vol_data)
        self.vols.append(vol)
        remplir_table(self.table_vols, self.vols, ["numero", "destination", "statut", "heure_decollage", "heure_arrivee", "avion_id", "pilote_id"])

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
