import argparse
import json
import mysql.connector
import PySimpleGUI as sg

def charger_config():
    parser = argparse.ArgumentParser(description="AirOps - Étape 2")
    parser.add_argument("--config", required=True, help="Chemin du fichier JSON")
    args = parser.parse_args()
    with open(args.config, 'r') as f:
        return json.load(f)

def connecter_mysql(config):
    conn = mysql.connector.connect(
        host=config['host'],
        user=config['user'],
        password=config['password'],
        database=config['database']
    )
    return conn

def lire_vols(conn):
    # TODO: Récupérer et retourner les vols depuis MySQL
    pass

def afficher_interface(vols):
    layout = [
        [sg.Text("Liste des vols")],
        [sg.Listbox(values=[f"{v[0]} → {v[1]}" for v in vols], size=(40, 10), key='-VOLLIST-')],
        [sg.Button("Rafraîchir"), sg.Button("Quitter")]
    ]

    window = sg.Window("AirOps Interface", layout)

    while True:
        event, _ = window.read()
        if event in (sg.WINDOW_CLOSED, "Quitter"):
            break
        if event == "Rafraîchir":
            # TODO: Recharger les vols et mettre à jour la liste
            pass

    window.close()

def main():
    config = charger_config()
    conn = connecter_mysql(config)
    vols = lire_vols(conn)
    afficher_interface(vols)
    conn.close()

if __name__ == "__main__":
    main()
