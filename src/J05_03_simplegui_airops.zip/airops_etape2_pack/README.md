# AirOps Étape 2 – Pack Participant

Ce pack contient :
- `app_gui.py` : squelette de l'application avec interface graphique PySimpleGUI.
- `config.json` : fichier de configuration pour MySQL.

## Objectif
Créer une application qui :
✅ Lit les vols existants depuis MySQL et les affiche dans une interface graphique.  
✅ Permet de rafraîchir les données avec un bouton.

## Instructions
1. Remplissez `app_gui.py` en complétant les fonctions `lire_vols` et la partie du bouton "Rafraîchir".  
2. Installez PySimpleGUI :
```
pip install PySimpleGUI
```
3. Testez l’application avec :
```
python app_gui.py --config config.json
```

Bonne chance !
