from modules.db import connecter, lire_vols
from modules.gui import afficher_interface
from modules.reporting import generer_rapport
from modules.utils import charger_config

def main():
    config = charger_config()
    conn = connecter(config)
    vols = lire_vols(conn)

    def rafraichir():
        nonlocal vols
        vols = lire_vols(conn)
        print("Vols rafraîchis")

    def generer():
        generer_rapport(vols)
        print("Rapport généré")

    afficher_interface(vols, {'rafraichir': rafraichir, 'generer_rapport': generer})
    conn.close()

if __name__ == "__main__":
    main()
