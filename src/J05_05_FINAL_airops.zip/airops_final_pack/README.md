# AirOps Final – Pack Formateur

Ce pack contient :
✅ Code complet prêt à être exécuté.  
✅ Modules séparés : base de données, interface, reporting, utils.  
✅ Fichier `app.py` principal.

## Instructions
1. Installez les dépendances :
```
pip install mysql-connector-python PySimpleGUI weasyprint
```
2. Assurez-vous que la base MySQL est disponible et remplie.  
3. Lancez l’application :
```
python app.py --config config.json
```

Bonne démo finale !
