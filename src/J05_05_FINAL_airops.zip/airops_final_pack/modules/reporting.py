from weasyprint import HTML

def generer_rapport(vols, fichier_pdf="rapport_final.pdf"):
    total = len(vols)
    paris_vols = [v for v in vols if v[1].lower() == "paris"]

    html = f"<h1>Rapport AirOps</h1><p>Total des vols : {total}</p><h2>Liste complète</h2><ul>"
    html += "".join(f"<li>{v[0]} → {v[1]}</li>" for v in vols)
    html += "</ul><h2>Vols vers Paris</h2><ul>"
    html += "".join(f"<li>{v[0]} → {v[1]}</li>" for v in paris_vols)
    html += "</ul>"

    HTML(string=html).write_pdf(fichier_pdf)
