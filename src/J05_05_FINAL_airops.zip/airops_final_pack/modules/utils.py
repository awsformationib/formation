import argparse
import json

def charger_config():
    parser = argparse.ArgumentParser(description="AirOps Final")
    parser.add_argument("--config", required=True, help="Chemin du fichier JSON")
    args = parser.parse_args()
    with open(args.config, 'r') as f:
        return json.load(f)
