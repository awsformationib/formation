import PySimpleGUI as sg

def afficher_interface(vols, callbacks):
    layout = [
        [sg.Text("Liste des vols")],
        [sg.Listbox(values=[f"{v[0]} → {v[1]}" for v in vols], size=(40, 10), key='-VOLLIST-')],
        [sg.Button("Rafraîchir"), sg.Button("Générer rapport PDF"), sg.Button("Quitter")]
    ]

    window = sg.Window("AirOps Final", layout)

    while True:
        event, _ = window.read()
        if event in (sg.WINDOW_CLOSED, "Quitter"):
            break
        if event == "Rafraîchir":
            callbacks['rafraichir']()
            vols = callbacks['rafraichir']()
            window['-VOLLIST-'].update([f"{v[0]} → {v[1]}" for v in vols])
        if event == "Générer rapport PDF":
            callbacks['generer_rapport']()
            sg.popup("Rapport PDF généré !", title="Succès")

    window.close()
