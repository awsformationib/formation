import mysql.connector

def connecter(config):
    return mysql.connector.connect(
        host=config['host'],
        user=config['user'],
        password=config['password'],
        database=config['database']
    )

def lire_vols(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT numero, destination FROM vols")
    return cursor.fetchall()

def ajouter_vol(conn, numero, destination):
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO vols (numero, destination) VALUES (%s, %s)",
        (numero, destination)
    )
    conn.commit()
