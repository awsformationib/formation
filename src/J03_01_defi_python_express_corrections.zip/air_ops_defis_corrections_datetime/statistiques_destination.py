from collections import Counter
from pathlib import Path
from datetime import datetime
import textwrap

def statistiques_par_destination(vols):
    stats = Counter(vol.destination for vol in vols)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    rapport = Path("exports") / f"rapport_destination_{timestamp}.txt"
    rapport.parent.mkdir(exist_ok=True)
    contenu = textwrap.dedent("""
        === Rapport des Destinations ===
    """)
    for dest, count in stats.items():
        contenu += f"{dest}: {count} vols\n"
    rapport.write_text(contenu)
    print(f"✅ Rapport écrit : {rapport}")
