# Atelier Défi Express – AirOps (Corrections Formateur avec datetime dans les noms de fichiers)

## Contenu
Chaque sous-dossier contient la correction complète du défi :
- statistiques_destination
- file_attente_decollage
- historique_affectations
- extension_rapports
- refactoring_typing

⚠️ Certains corrigés introduisent volontairement des modules standards **non encore vus** comme `itertools`, `textwrap`, `zipfile` et utilisent **datetime pour intégrer la date/heure dans les noms de fichiers**, afin d’ouvrir des discussions supplémentaires.

## Usage
Vous pouvez distribuer ces corrections après l’atelier pour comparaison, ou les utiliser comme support de discussion.

Bon débrief !
