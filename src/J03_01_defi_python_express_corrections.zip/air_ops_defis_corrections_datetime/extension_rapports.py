import csv
import json
from pathlib import Path
from datetime import datetime
import zipfile

def generer_rapports(vols):
    dossier = Path("exports")
    dossier.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # CSV
    chemin_csv = dossier / f"vols_{timestamp}.csv"
    with chemin_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Numéro", "Destination", "Statut"])
        for vol in vols:
            writer.writerow([vol.id, vol.numero, vol.destination, vol.statut.value])

    # JSON
    chemin_json = dossier / f"vols_{timestamp}.json"
    vols_data = [{
        "id": vol.id,
        "numero": vol.numero,
        "destination": vol.destination,
        "statut": vol.statut.value
    } for vol in vols]
    with chemin_json.open("w", encoding="utf-8") as f:
        json.dump(vols_data, f, indent=4, ensure_ascii=False)

    # ZIP archive
    zip_path = dossier / f"rapports_{timestamp}.zip"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.write(chemin_csv, arcname=f"vols_{timestamp}.csv")
        zf.write(chemin_json, arcname=f"vols_{timestamp}.json")

    print(f"✅ Rapports générés et archivés dans : {zip_path}")
