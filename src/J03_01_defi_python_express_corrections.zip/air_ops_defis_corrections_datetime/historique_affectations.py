import json
from datetime import datetime
from uuid import uuid4
from pathlib import Path

def sauvegarder_historique(affectations):
    historique = []
    for aff in affectations:
        historique.append({
            "id": str(uuid4()),
            "vol": aff.vol.numero,
            "piste": aff.piste.numero,
            "heure": datetime.now().isoformat()
        })
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    chemin = Path("exports") / f"historique_{timestamp}.json"
    chemin.parent.mkdir(exist_ok=True)
    with chemin.open("w", encoding="utf-8") as f:
        json.dump(historique, f, indent=4, ensure_ascii=False)
    print(f"✅ Historique sauvegardé : {chemin}")
