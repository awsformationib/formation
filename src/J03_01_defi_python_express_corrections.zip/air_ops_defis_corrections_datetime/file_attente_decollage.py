from collections import deque
from datetime import datetime
import itertools

def gerer_file_attente(vols):
    file = deque(vols)
    for i, vol in enumerate(itertools.islice(file, 0, len(file))):
        heure = datetime.now().strftime("%H:%M:%S")
        print(f"[{heure}] Décollage #{i+1}: {vol.numero} → {vol.destination}")
        file.popleft()
