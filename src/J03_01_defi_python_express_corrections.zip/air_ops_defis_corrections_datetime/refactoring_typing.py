from typing import List, Optional, Dict
from avion import Avion
from vol import Vol
from piste import Piste
from affectation import Affectation

def exemple_typing(avions: List[Avion], vols: List[Vol], pistes: List[Piste], affectations: List[Affectation]) -> Dict[str, int]:
    resultat = { "total_avions": len(avions), "total_vols": len(vols), "total_pistes": len(pistes) }
    return resultat
