class Vol:
    def __init__(self, numero):
        self.numero = numero

    def afficher_details(self):
        return f"Vol {self.numero}"

class VolPassagers(Vol):
    def __init__(self, numero, nb_passagers):
        super().__init__(numero)
        self.nb_passagers = nb_passagers

    def afficher_details(self):
        return super().afficher_details() + f" avec {self.nb_passagers} passagers"

class VolCargo(Vol):
    def __init__(self, numero, capacite_tonnes):
        super().__init__(numero)
        self.capacite_tonnes = capacite_tonnes

    def afficher_details(self):
        return super().afficher_details() + f" transportant {self.capacite_tonnes} tonnes"
