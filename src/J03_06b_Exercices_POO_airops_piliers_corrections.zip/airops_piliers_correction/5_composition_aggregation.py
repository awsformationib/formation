class PlanDeVol:
    def __init__(self, details):
        self.details = details

class VolPassagers:
    def __init__(self, numero, plan_de_vol):
        self.numero = numero
        self.plan_de_vol = plan_de_vol  # Composition

class Pilote:
    def __init__(self, nom):
        self.nom = nom

class VolCargo:
    def __init__(self, numero):
        self.numero = numero
        self.pilotes = []  # Agrégation

    def ajouter_pilote(self, pilote):
        self.pilotes.append(pilote)
