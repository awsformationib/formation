def afficher_presentations(personnels):
    for p in personnels:
        print(p.presenter())

class Pilote:
    def presenter(self):
        return "Je suis un pilote."

class AgentSol:
    def presenter(self):
        return "Je suis un agent au sol."

# Exemple d'utilisation
pilote = Pilote()
agent = AgentSol()
afficher_presentations([pilote, agent])
