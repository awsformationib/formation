class Avion:
    def __init__(self, immatriculation, modele):
        self._immatriculation = immatriculation
        self._modele = modele

    def get_immatriculation(self):
        return self._immatriculation

    def get_modele(self):
        return self._modele
