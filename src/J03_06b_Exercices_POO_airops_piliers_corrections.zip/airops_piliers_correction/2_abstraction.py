from abc import ABC, abstractmethod

class Personnel(ABC):
    @abstractmethod
    def presenter(self):
        pass

class Pilote(Personnel):
    def presenter(self):
        return "Je suis un pilote."

class AgentSol(Personnel):
    def presenter(self):
        return "Je suis un agent au sol."
