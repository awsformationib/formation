# AirOps Étape 4 – Pack Participant

Ce pack contient :
- `app_gui_pdf_plus.py` : squelette de l'application avec interface graphique et génération PDF.
- `config.json` : fichier de configuration pour MySQL.

## Objectif
Créer une application qui :
✅ Lit les vols existants depuis MySQL.  
✅ Affiche les vols dans une interface graphique PySimpleGUI.  
✅ Génère un rapport PDF enrichi avec résumé et liste filtrée.

## Instructions
1. Remplissez `app_gui_pdf_plus.py` en complétant les fonctions.  
2. Installez les dépendances :
```
pip install PySimpleGUI weasyprint
```
3. Testez l’application avec :
```
python app_gui_pdf_plus.py --config config.json
```

Bonne chance !
