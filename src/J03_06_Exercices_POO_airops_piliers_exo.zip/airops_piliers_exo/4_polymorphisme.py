# Étape 4 : Polymorphisme
# TODO : Écrivez une fonction afficher_presentations(personnels) qui appelle presenter() sur chaque élément de la liste.
# Testez avec Pilote et AgentSol.
