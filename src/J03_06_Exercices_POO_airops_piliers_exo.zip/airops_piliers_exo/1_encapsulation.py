# Étape 1 : Encapsulation
# TODO : Créez une classe Avion avec des attributs privés (_immatriculation, _modele)
# Ajoutez des méthodes publiques pour les lire.
