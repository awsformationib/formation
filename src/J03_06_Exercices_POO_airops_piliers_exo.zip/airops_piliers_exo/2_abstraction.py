# Étape 2 : Abstraction
# TODO : Créez une classe abstraite Personnel avec une méthode presenter().
# Créez Pilote et AgentSol qui héritent de Personnel et implémentent presenter().
