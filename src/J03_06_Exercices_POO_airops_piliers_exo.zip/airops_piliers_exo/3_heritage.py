# Étape 3 : Héritage
# TODO : Créez une classe Vol générale et deux sous-classes : VolPassagers et VolCargo.
# Factorisez les comportements communs et ajoutez des attributs spécifiques.
