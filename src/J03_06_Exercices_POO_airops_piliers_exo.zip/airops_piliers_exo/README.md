# Exercice Fil Rouge – Les 5 Piliers de la POO

Ce pack contient 5 fichiers Python, un par pilier :

1. Encapsulation
2. Abstraction
3. Héritage
4. Polymorphisme
5. Composition et Agrégation

À chaque étape, lisez les instructions dans le fichier correspondant et complétez le code.

Bonne pratique !
