# Étape 5 : Composition et Agrégation
# TODO : Dans VolPassagers, ajoutez un PlanDeVol (composition).
# Dans VolCargo, reliez plusieurs Pilote (agrégation).
