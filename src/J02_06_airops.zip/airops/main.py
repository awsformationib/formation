from avion import Avion
from vol import Vol
from piste import Piste
from affectation import Affectation

# Création des ressources
avion1 = Avion("F-GKXJ", "A320")
vol1 = Vol("AF123", "Lyon", avion1)
piste1 = Piste("27L", 3900)

# Affectation et déroulement
print(vol1)
print(piste1)

affect = Affectation(vol1, piste1)
affect.effectuer()
print(vol1)
print(piste1)

affect.liberer()
print(vol1)
print(piste1)
