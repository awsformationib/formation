class Piste:
    def __init__(self, numero, longueur):
        self.numero = numero
        self.longueur = longueur
        self.occupee = False

    def liberer(self):
        self.occupee = False

    def occuper(self):
        self.occupee = True

    def __str__(self):
        etat = "occupée" if self.occupee else "libre"
        return f"Piste {self.numero} ({self.longueur}m) – {etat}"
