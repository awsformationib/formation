class Vol:
    def __init__(self, numero, destination, avion):
        self.numero = numero
        self.destination = destination
        self.avion = avion
        self.statut = "prévu"

    def changer_statut(self, nouveau):
        transitions = {
            "prévu": ["en cours"],
            "en cours": ["terminé"],
            "terminé": []
        }
        if nouveau in transitions[self.statut]:
            self.statut = nouveau

    def __str__(self):
        return f"Vol {self.numero} vers {self.destination} [{self.statut}] – {self.avion}"

    def __repr__(self):
        return f"Vol('{self.numero}', '{self.destination}', {repr(self.avion)})"

    def __eq__(self, other):
        return self.numero == other.numero

    def __hash__(self):
        return hash(self.numero)
