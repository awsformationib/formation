class Affectation:
    def __init__(self, vol, piste):
        self.vol = vol
        self.piste = piste

    def effectuer(self):
        if not self.piste.occupee and self.vol.statut == "prévu":
            self.piste.occuper()
            self.vol.changer_statut("en cours")
            print(f"✔️ {self.vol.numero} affecté à la {self.piste.numero}")
        else:
            print(f"❌ Affectation échouée : {self.vol.numero} / {self.piste.numero}")

    def liberer(self):
        self.piste.liberer()
        self.vol.changer_statut("terminé")
        print(f"🛬 {self.vol.numero} a terminé. Piste {self.piste.numero} libérée.")

    def __str__(self):
        return f"Affectation : {self.vol.numero} ←→ {self.piste.numero}"
