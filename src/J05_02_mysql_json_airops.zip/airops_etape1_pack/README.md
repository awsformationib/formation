# AirOps Étape 1 – Pack Participant

Ce pack contient :
- `app.py` : squelette de l'application principale.
- `config.json` : fichier de configuration pour MySQL.

## Objectif
Créer une application qui :
✅ Lit les vols existants depuis MySQL au démarrage.  
✅ Ajoute de nouveaux vols à la fin de l'exécution.

## Instructions
1. Remplissez `app.py` en complétant les fonctions `lire_vols` et `ajouter_vol`.  
2. Testez le programme avec :
```
python app.py --config config.json
```
3. Vérifiez les résultats directement dans votre base MySQL.

Bonne chance !
