import argparse
import json
import mysql.connector

def charger_config():
    parser = argparse.ArgumentParser(description="AirOps - Étape 1")
    parser.add_argument("--config", required=True, help="Chemin du fichier de configuration JSON")
    args = parser.parse_args()
    with open(args.config, 'r') as f:
        config = json.load(f)
    return config

def connecter_mysql(config):
    conn = mysql.connector.connect(
        host=config['host'],
        user=config['user'],
        password=config['password'],
        database=config['database']
    )
    return conn

def lire_vols(conn):
    # TODO: Récupérer et afficher les vols existants
    pass

def ajouter_vol(conn, numero, destination):
    # TODO: Insérer un nouveau vol dans la base
    pass

def main():
    config = charger_config()
    conn = connecter_mysql(config)

    # TODO: Lire les vols existants
    # TODO: Ajouter de nouveaux vols (ex: AF456, BA789)

    conn.close()

if __name__ == "__main__":
    main()
