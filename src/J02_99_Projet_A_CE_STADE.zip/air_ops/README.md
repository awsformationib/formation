# Projet AirOps – Version Intégratrice (J1 + J2)

## Objectif
Ce projet regroupe tous les apprentissages réalisés durant les jours 1 et 2 :
- POO : classes, instances, méthodes, encapsulation, dataclasses, Enum, méthodes spéciales
- Modules standards : datetime, random, uuid, collections, pathlib, csv, json, typing

## Structure
- `avion.py` : gestion des avions
- `vol.py` : gestion des vols
- `piste.py` : gestion des pistes
- `affectation.py` : liens vol-piste
- `simulateur.py` : génération aléatoire
- `exporter.py` : export CSV/JSON
- `main.py` : script principal

## Instructions
1. Exécutez `main.py` :
    ```bash
    python main.py
    ```
2. Vérifiez les fichiers générés dans le dossier `exports/` :
    - `vols.csv` : tableau des vols
    - `vols.json` : fichier JSON structuré

3. Pour explorer :
    - Ajoutez d’autres formats d’export
    - Étendez les statistiques avec `collections.Counter`
    - Ajoutez une interface simple (console ou GUI)

## Objectif pédagogique
Tout le monde repart avec une base commune, complète, prête à enrichir au jour 3.
