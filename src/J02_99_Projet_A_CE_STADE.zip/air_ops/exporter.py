import csv
import json
from pathlib import Path
from vol import Vol

def exporter_csv(vols: list[Vol], chemin: Path) -> None:
    chemin.parent.mkdir(exist_ok=True)
    with chemin.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Numéro", "Destination", "Statut"])
        for vol in vols:
            writer.writerow([vol.id, vol.numero, vol.destination, vol.statut.value])

def exporter_json(vols: list[Vol], chemin: Path) -> None:
    chemin.parent.mkdir(exist_ok=True)
    vols_data = [{
        "id": vol.id,
        "numero": vol.numero,
        "destination": vol.destination,
        "statut": vol.statut.value
    } for vol in vols]
    with chemin.open("w", encoding="utf-8") as f:
        json.dump(vols_data, f, indent=4, ensure_ascii=False)
