from simulateur import generer_avion, generer_vol, generer_piste
from affectation import Affectation
from exporter import exporter_csv, exporter_json
from pathlib import Path

# Génération des ressources
avions = [generer_avion() for _ in range(5)]
pistes = [generer_piste() for _ in range(2)]
vols = [generer_vol(choice(avions)) for _ in range(10)]

# Affectation des vols aux pistes
affectations = []
for vol, piste in zip(vols, pistes * 5):  # répartir sur les pistes
    aff = Affectation(vol, piste)
    aff.effectuer()
    aff.liberer()
    affectations.append(aff)

# Export des résultats
exporter_csv(vols, Path("exports/vols.csv"))
exporter_json(vols, Path("exports/vols.json"))

print("✅ Exécution complète : export CSV et JSON réalisés.")
