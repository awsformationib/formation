from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
from uuid import uuid4
from datetime import datetime
from avion import Avion

class StatutVol(Enum):
    PREVU = "prévu"
    EN_COURS = "en cours"
    TERMINE = "terminé"

@dataclass
class Vol:
    numero: str
    destination: str
    avion: Avion
    statut: StatutVol = StatutVol.PREVU
    id: str = field(default_factory=lambda: str(uuid4()))
    heure_decollage: Optional[datetime] = None
    heure_arrivee: Optional[datetime] = None

    def decoller(self) -> None:
        self.statut = StatutVol.EN_COURS
        self.heure_decollage = datetime.now()

    def atterrir(self) -> None:
        self.statut = StatutVol.TERMINE
        self.heure_arrivee = datetime.now()

    def __str__(self) -> str:
        return f"{self.numero} → {self.destination} [{self.statut.value}]"
