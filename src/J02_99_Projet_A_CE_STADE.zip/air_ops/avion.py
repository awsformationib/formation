from dataclasses import dataclass, field
from uuid import uuid4

@dataclass
class Avion:
    immatriculation: str
    modele: str
    id: str = field(default_factory=lambda: str(uuid4()))

    def __str__(self) -> str:
        return f"{self.immatriculation} ({self.modele})"
