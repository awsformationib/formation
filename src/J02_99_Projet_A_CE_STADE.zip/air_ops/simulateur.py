from random import choice, randint
from avion import Avion
from vol import Vol
from piste import Piste

VILLES = ["Lyon", "Nice", "Toulouse", "Bordeaux", "Lille"]
COMPAGNIES = ["AF", "BA", "LH", "IB"]
MODELES = ["A320", "B737", "E190"]

def generer_avion() -> Avion:
    return Avion(
        immatriculation=f"F-{''.join(choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(3))}",
        modele=choice(MODELES)
    )

def generer_vol(avion: Avion) -> Vol:
    return Vol(
        numero=f"{choice(COMPAGNIES)}{randint(100,999)}",
        destination=choice(VILLES),
        avion=avion
    )

def generer_piste() -> Piste:
    return Piste(numero=f"{randint(10,99)}L", longueur=randint(2000, 4000))
