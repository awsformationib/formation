# Atelier Défi Express – AirOps

## Objectif
Complétez le défi choisi dans votre dossier dédié :
- statistiques_destination
- file_attente_decollage
- historique_affectations
- extension_rapports
- refactoring_typing

Chaque dossier contient un fichier `.py` partiellement préparé à compléter.

## Règles
- Travaillez uniquement dans votre dossier défi.
- Combinez au moins 5 modules standards vus ensemble.
- Vous pouvez réutiliser les classes de base de AirOps (`avion`, `vol`, `piste`, etc.) si besoin.

Bon code !
