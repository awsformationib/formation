# TODO : Complétez ce fichier pour calculer les statistiques par destination
# Indice : utilisez collections.Counter et enregistrez un rapport texte avec pathlib
