# TODO : Complétez ce fichier pour produire un rapport complet (CSV, JSON, texte, console)
# Utilisez csv, json, pathlib, et affichez un résumé dans le terminal
