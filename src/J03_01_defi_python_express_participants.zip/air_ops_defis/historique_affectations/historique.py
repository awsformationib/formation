# TODO : Complétez ce fichier pour sauvegarder l'historique des affectations
# Format de sortie : JSON (module json), avec heure (datetime) et ID (uuid)
