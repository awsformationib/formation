# TODO : Complétez ce fichier en ajoutant des annotations typing aux autres modules
# Utilisez List, Dict, Optional, etc. Vérifiez la cohérence des signatures
