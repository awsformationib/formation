# TODO : Complétez ce fichier pour gérer une file d’attente avec collections.deque
# Simulez les départs et affichez l'ordre des décollages
