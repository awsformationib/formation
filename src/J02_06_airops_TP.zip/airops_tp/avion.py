class Avion:
    def __init__(self, immatriculation, modele):
        self.immatriculation = immatriculation
        self.modele = modele

    def __str__(self):
        return f"{self.immatriculation} ({self.modele})"

    def __repr__(self):
        return f"Avion('{self.immatriculation}', '{self.modele}')"

    def __eq__(self, other):
        return self.immatriculation == other.immatriculation

    def __hash__(self):
        return hash(self.immatriculation)
