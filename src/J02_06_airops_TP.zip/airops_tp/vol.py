class Vol:
    def __init__(self, numero, destination, avion):
        self.numero = numero
        self.destination = destination
        self.avion = avion
        self.statut = "prévu"

    # TODO : __str__ → afficher le vol lisiblement
    # TODO : __repr__ → version développeur
    # TODO : __eq__ → comparer deux vols par numéro
    # TODO : __hash__ → pour set/dict
    # TODO : changer_statut → autoriser transitions prévues → en cours → terminé
