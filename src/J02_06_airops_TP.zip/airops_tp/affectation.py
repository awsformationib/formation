class Affectation:
    def __init__(self, vol, piste):
        self.vol = vol
        self.piste = piste

    # TODO : méthode effectuer()
    # Si piste libre et vol prévu → piste occupée, vol en cours

    # TODO : méthode liberer()
    # Libérer la piste, terminer le vol

    # TODO : méthode __str__()
