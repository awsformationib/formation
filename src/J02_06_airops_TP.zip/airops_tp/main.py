from avion import Avion
from vol import Vol
from piste import Piste
from affectation import Affectation

# Étape 1 : créer un avion
avion1 = Avion("F-GKXJ", "A320")

# Étape 2 : créer un vol assigné à cet avion
vol1 = Vol("AF123", "Lyon", avion1)

# Étape 3 : créer une piste d’atterrissage
piste1 = Piste("27L", 3900)

# Étape 4 : afficher les objets créés
print(vol1)
print(piste1)

# Étape 5 : créer une affectation
affect = Affectation(vol1, piste1)

# Étape 6 : tester la méthode affect.effectuer()
affect.effectuer()
print(vol1)
print(piste1)

# Étape 7 : libérer la piste et terminer le vol
affect.liberer()
print(vol1)
print(piste1)
