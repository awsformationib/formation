class Piste:
    def __init__(self, numero, longueur):
        self.numero = numero
        self.longueur = longueur
        self.occupee = False

    # TODO : méthode __str__ → affiche état lisible
    # TODO : méthode occuper()
    # TODO : méthode liberer()
